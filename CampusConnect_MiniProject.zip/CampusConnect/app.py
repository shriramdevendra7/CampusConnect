import os
import csv
import io
from datetime import datetime, date
from functools import wraps

import click
from flask import Flask, render_template, redirect, url_for, flash, request, Response, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from flask_wtf import FlaskForm
from flask_wtf.csrf import CSRFProtect
from wtforms import StringField, PasswordField, TextAreaField, DateField, TimeField, IntegerField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length, NumberRange, EqualTo, Optional, ValidationError
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-development-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///campusconnect.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "warning"
csrf = CSRFProtect(app)


# ----------------------------- Database models -----------------------------

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="student")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    registrations = db.relationship("Registration", back_populates="student", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    venue = db.Column(db.String(120), nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    event_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, nullable=False, default=50)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    registrations = db.relationship("Registration", back_populates="event", cascade="all, delete-orphan")

    @property
    def registered_count(self):
        return len(self.registrations)

    @property
    def available_seats(self):
        return max(0, self.capacity - self.registered_count)


class Registration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey("event.id"), nullable=False)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    attended = db.Column(db.Boolean, nullable=False, default=False)

    student = db.relationship("User", back_populates="registrations")
    event = db.relationship("Event", back_populates="registrations")
    __table_args__ = (db.UniqueConstraint("student_id", "event_id", name="unique_student_event"),)


@app.context_processor
def inject_today():
    return {"today": date.today()}


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# --------------------------------- Forms ------------------------------------

class RegisterForm(FlaskForm):
    name = StringField("Full name", validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField("College email", validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField("Confirm password", validators=[DataRequired(), EqualTo("password")])
    submit = SubmitField("Create account")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class EventForm(FlaskForm):
    title = StringField("Event title", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Description", validators=[DataRequired(), Length(min=20)])
    category = SelectField("Category", choices=[
        ("Technical", "Technical"), ("Cultural", "Cultural"),
        ("Sports", "Sports"), ("Workshop", "Workshop"), ("Other", "Other")
    ], validators=[DataRequired()])
    venue = StringField("Venue", validators=[DataRequired(), Length(max=120)])
    event_date = DateField("Event date", validators=[DataRequired()])
    event_time = TimeField("Event time", validators=[DataRequired()])
    capacity = IntegerField("Maximum participants", validators=[DataRequired(), NumberRange(min=1, max=10000)])
    submit = SubmitField("Save event")


# ------------------------------ Helper logic -------------------------------

def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if current_user.role != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def event_form_from_event(event):
    form = EventForm(obj=event)
    if request.method == "GET":
        form.event_date.data = event.event_date
        form.event_time.data = event.event_time
    return form


# --------------------------------- Routes -----------------------------------

@app.route("/")
def index():
    search = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    query = Event.query.filter(Event.event_date >= date.today())
    if search:
        pattern = f"%{search}%"
        query = query.filter(db.or_(Event.title.ilike(pattern), Event.description.ilike(pattern), Event.venue.ilike(pattern)))
    if category:
        query = query.filter_by(category=category)
    events = query.order_by(Event.event_date.asc(), Event.event_time.asc()).all()
    categories = ["Technical", "Cultural", "Sports", "Workshop", "Other"]
    return render_template("index.html", events=events, search=search, category=category, categories=categories)


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("index"))
    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        if User.query.filter_by(email=email).first():
            flash("An account with this email already exists.", "danger")
        else:
            user = User(name=form.name.data.strip(), email=email, role="student")
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Account created. Welcome to CampusConnect!", "success")
            return redirect(url_for("index"))
    return render_template("auth.html", form=form, page_title="Create account", register=True)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower().strip()).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash(f"Welcome back, {user.name}!", "success")
            next_page = request.args.get("next")
            if next_page and next_page.startswith("/") and not next_page.startswith("//"):
                return redirect(next_page)
            return redirect(url_for("index"))
        flash("Invalid email or password.", "danger")
    return render_template("auth.html", form=form, page_title="Login", register=False)


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/event/<int:event_id>")
def event_detail(event_id):
    event = db.get_or_404(Event, event_id)
    registration = None
    if current_user.is_authenticated:
        registration = Registration.query.filter_by(student_id=current_user.id, event_id=event.id).first()
    return render_template("event_detail.html", event=event, registration=registration)


@app.route("/event/<int:event_id>/register", methods=["POST"])
@login_required
def register_for_event(event_id):
    if current_user.role != "student":
        abort(403)
    event = db.get_or_404(Event, event_id)
    existing = Registration.query.filter_by(student_id=current_user.id, event_id=event.id).first()
    if existing:
        flash("You are already registered for this event.", "info")
    elif event.event_date < date.today():
        flash("Registration is closed because this event has already passed.", "warning")
    elif event.available_seats <= 0:
        flash("Sorry, this event is full.", "danger")
    else:
        db.session.add(Registration(student_id=current_user.id, event_id=event.id))
        db.session.commit()
        flash("Registration successful. See you there!", "success")
    return redirect(url_for("event_detail", event_id=event.id))


@app.route("/my-events")
@login_required
def my_events():
    registrations = Registration.query.filter_by(student_id=current_user.id).join(Event).order_by(Event.event_date.asc()).all()
    return render_template("my_events.html", registrations=registrations)


@app.route("/admin")
@admin_required
def admin_dashboard():
    events = Event.query.order_by(Event.event_date.desc()).all()
    return render_template("admin_dashboard.html", events=events,
                           student_count=User.query.filter_by(role="student").count(),
                           registration_count=Registration.query.count())


@app.route("/admin/event/new", methods=["GET", "POST"])
@admin_required
def create_event():
    form = EventForm()
    if form.validate_on_submit():
        event = Event(
            title=form.title.data.strip(), description=form.description.data.strip(),
            category=form.category.data, venue=form.venue.data.strip(),
            event_date=form.event_date.data, event_time=form.event_time.data,
            capacity=form.capacity.data, created_by=current_user.id
        )
        db.session.add(event)
        db.session.commit()
        flash("Event created successfully.", "success")
        return redirect(url_for("admin_dashboard"))
    return render_template("event_form.html", form=form, page_title="Create event")


@app.route("/admin/event/<int:event_id>/edit", methods=["GET", "POST"])
@admin_required
def edit_event(event_id):
    event = db.get_or_404(Event, event_id)
    form = event_form_from_event(event)
    if form.validate_on_submit():
        if form.capacity.data < event.registered_count:
            flash("Capacity cannot be lower than the current number of registrations.", "danger")
        else:
            form.populate_obj(event)
            db.session.commit()
            flash("Event updated.", "success")
            return redirect(url_for("admin_dashboard"))
    return render_template("event_form.html", form=form, page_title="Edit event")


@app.route("/admin/event/<int:event_id>/delete", methods=["POST"])
@admin_required
def delete_event(event_id):
    event = db.get_or_404(Event, event_id)
    db.session.delete(event)
    db.session.commit()
    flash("Event and its registrations were deleted.", "info")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/event/<int:event_id>/attendees")
@admin_required
def attendees(event_id):
    event = db.get_or_404(Event, event_id)
    registrations = Registration.query.filter_by(event_id=event.id).join(User).order_by(User.name.asc()).all()
    return render_template("attendees.html", event=event, registrations=registrations)


@app.route("/admin/registration/<int:registration_id>/attendance", methods=["POST"])
@admin_required
def toggle_attendance(registration_id):
    registration = db.get_or_404(Registration, registration_id)
    registration.attended = not registration.attended
    db.session.commit()
    flash("Attendance updated.", "success")
    return redirect(url_for("attendees", event_id=registration.event_id))


@app.route("/admin/reports/registrations.csv")
@admin_required
def export_registrations():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Event", "Category", "Date", "Venue", "Student Name", "Student Email", "Registered At", "Attended"])
    rows = Registration.query.join(Event).join(User).order_by(Event.event_date, User.name).all()
    for r in rows:
        writer.writerow([r.event.title, r.event.category, r.event.event_date.isoformat(),
                         r.event.venue, r.student.name, r.student.email,
                         r.registered_at.strftime("%Y-%m-%d %H:%M"), "Yes" if r.attended else "No"])
    return Response(output.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=campusconnect_registrations.csv"})


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="You do not have permission to view this page."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="The page or record you requested was not found."), 404


@app.cli.command("init-db")
def init_db():
    """Create database tables."""
    db.create_all()
    click.echo("Database tables created.")


@app.cli.command("create-admin")
@click.option("--name", prompt="Admin name")
@click.option("--email", prompt="Admin email")
@click.password_option()
def create_admin(name, email, password):
    """Create an administrator account."""
    db.create_all()
    email = email.lower().strip()
    if User.query.filter_by(email=email).first():
        click.echo("An account with that email already exists.")
        return
    admin = User(name=name.strip(), email=email, role="admin")
    admin.set_password(password)
    db.session.add(admin)
    db.session.commit()
    click.echo(f"Admin account created for {email}.")


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
