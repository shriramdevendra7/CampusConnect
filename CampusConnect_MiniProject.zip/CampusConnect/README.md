# CampusConnect – College Event & Club Management System

CampusConnect is an intermediate-level Python mini-project built with Flask and SQLite. It helps students discover college events and register online, while administrators can publish events, manage participants, mark attendance and export registration reports.

## Features

### Student
- Create an account and securely log in.
- Browse upcoming college events.
- Search by event title, description or venue.
- Filter events by category.
- View event details and remaining seats.
- Register for an event and view personal registrations.

### Administrator
- Create, edit and delete events.
- View dashboard statistics.
- View the attendee list for each event.
- Mark participant attendance.
- Export all registrations as a CSV spreadsheet.

### Technical features
- Flask web framework and SQLite database.
- SQLAlchemy ORM and relational database models.
- Password hashing using Werkzeug.
- Session-based authentication with Flask-Login.
- CSRF protection on forms using Flask-WTF.
- Role-based access control for administrator pages.
- Unique constraint prevents duplicate event registrations.

## Technology stack
- Python 3.10+
- Flask
- Flask-SQLAlchemy
- Flask-Login
- Flask-WTF
- SQLite
- HTML, CSS, Bootstrap 5

## Project structure

```text
CampusConnect/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── .env.example
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── auth.html
│   ├── event_detail.html
│   ├── my_events.html
│   ├── admin_dashboard.html
│   ├── event_form.html
│   ├── attendees.html
│   └── error.html
└── static/
    └── css/
        └── style.css
```

## Installation and setup

### 1. Install Python
Install Python 3.10 or newer. Check the installation:

```bash
python --version
```

### 2. Open the project folder

```bash
cd CampusConnect
```

### 3. Create and activate a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure environment variables

Copy `.env.example` to `.env`, then replace `SECRET_KEY` with a long random secret. The app reads environment variables from the shell; to load `.env` automatically, run it with Flask's dotenv support (installed with Flask) or add `from dotenv import load_dotenv; load_dotenv()` near the top of `app.py`.

### 6. Create the database

The database tables are created automatically when `app.py` starts. You can also run:

```bash
flask --app app init-db
```

### 7. Create an administrator

```bash
flask --app app create-admin
```

Enter the administrator's name, email and a strong password when prompted.

### 8. Run the application

```bash
flask --app app run --debug
```

Open **http://127.0.0.1:5000** in your browser.

## How to use

1. Register a normal student account from the home page.
2. Log out and sign in using the administrator account created in step 7.
3. Open **Admin** and create one or more upcoming events.
4. Log in as a student, browse events and register.
5. Return to the administrator account to view attendees and mark attendance.
6. Download the CSV report from the admin dashboard.

## Database design

- **User**: stores name, email, password hash and role (`student` or `admin`).
- **Event**: stores event title, description, category, venue, date, time, capacity and creator.
- **Registration**: links a student to an event, stores registration time and attendance status. A unique constraint on `(student_id, event_id)` prevents duplicate registrations.

## Important notes

- This is an academic demonstration project. Before deploying publicly, set a strong secret key, disable debug mode, configure HTTPS, review security settings and use a production WSGI server.
- Do not commit `.env`, database files, passwords or personal data to GitHub.
- The application uses SQLite by default and creates `campusconnect.db` automatically.
- The project does not send emails or process payments.

## Future enhancements
- Email notifications and event reminders.
- QR-code attendance.
- Student club pages and club membership.
- Event feedback and ratings.
- Charts for event participation.

## Author
**Student Name:** Add your name here  
**Course:** B.Tech – Computer Science and Engineering  
**Project:** Python Mini Project  
